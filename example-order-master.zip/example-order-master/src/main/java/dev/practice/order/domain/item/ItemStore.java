package dev.practice.order.domain.item;

public interface ItemStore {
    Item store(Item initItem);
}
