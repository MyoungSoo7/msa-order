package dev.practice.order.domain.partner;

public interface PartnerStore {
    Partner store(Partner initPartner);
}
