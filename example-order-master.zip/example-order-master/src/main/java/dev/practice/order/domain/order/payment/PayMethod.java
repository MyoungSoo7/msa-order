package dev.practice.order.domain.order.payment;

public enum PayMethod {
    CARD, NAVER_PAY, TOSS_PAY, KAKAO_PAY
}
