package dev.practice.order.domain.item.option;

public interface ItemOptionStore {
    void store(ItemOption itemOption);
}
