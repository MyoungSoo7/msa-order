package dev.practice.order.domain.item.optiongroup;

public interface ItemOptionGroupStore {
    ItemOptionGroup store(ItemOptionGroup itemOptionGroup);
}
